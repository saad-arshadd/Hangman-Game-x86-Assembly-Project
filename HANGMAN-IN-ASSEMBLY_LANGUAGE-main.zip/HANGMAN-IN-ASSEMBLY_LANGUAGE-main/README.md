This code will run on VISUAL STUDIO COMMUNITY version after configuring it to run the "Assembly Language-8086" and linking "Irvine32" library.
